# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AAAWebsite::Application.config.secret_token = '0682686df8236d474c8d00cb5bc43a74d5efb375274a425295b13b43b3f4ea3bcd8d241ea5621b66ad439c72b6e4759fa9f640cbb5de2fa60a2e0b0f57ca46e6'
