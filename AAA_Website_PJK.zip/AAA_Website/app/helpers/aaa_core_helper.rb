module AaaCoreHelper
end
