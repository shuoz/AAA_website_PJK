require 'test_helper'

class AaaCoreHelperTest < ActionView::TestCase
end
